<?php
include "database.php";

$sql = "SELECT * FROM product";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Shopping Site</title>
    <style>
		body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: #f1f3f6;
}

/* HEADER */
header {
    background: #131921;
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h2 {
    margin: 0;
}

header a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
}

/* BANNER */
.banner {
    background: url('https://images.unsplash.com/photo-1607082348824-0a96f2a4b9b2');
    background-size: cover;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 30px;
    font-weight: bold;
}

/* PRODUCT GRID */
.products {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    padding: 30px;
}

/* PRODUCT CARD */
.card {
    background: white;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    transition: 0.3s;
    text-align: center;
}

.card:hover {
    transform: scale(1.05);
}

.card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 8px;
}

.price {
    color: green;
    font-weight: bold;
    font-size: 18px;
}

/* BUTTON */
.btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px;
    background: #ff9f00;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.btn:hover {
    background: #fb8c00;
}

    </style>
</head>
<body>

<header>
    <h1>🛒 My Shop</h1>
    <div>
        <a href="#">Home</a>
        <a href="cart.php">Cart</a>
        <a href="logout.php">Logout</a>
        
    </div>
</header>

<div class="banner">
    Big Sale Today - Up to 70% OFF
</div>

<div class="product">

<?php while($row = $result->fetch_assoc()){ ?>

    <div class="card">

        <img src="<?php echo $row['image']; ?>" alt="product">

        <h3><?php echo $row['name']; ?></h3>

        <p><?php echo $row['description']; ?></p>

        <div class="price">₹<?php echo $row['price']; ?></div>

        <a href="buynow.php?id=<?php echo $roe['id']; ?>" class="btn">
           Buy now
           </a>
        <a href="cart_action.php?id=<?php echo $row['id']; ?>" class="btn">
            Add to Cart
        </a>

    </div>

<?php } ?>

</div>

</body>
</html>
