<?php

$message = "";

if(isset($_POST['pay'])){

    $payment = $_POST['payment'];

    if(empty($payment)){
        $message = "Please select a payment method";
    } else {
        $message = "Payment Successful using " . $payment;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f4f4;
        }

        .container{
            width:350px;
            margin:100px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px #ccc;
        }

        h2{
            text-align:center;
        }

        button{
            width:100%;
            padding:10px;
            background:green;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
        }

        .msg{
            color:green;
            text-align:center;
            margin-bottom:10px;
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Payment Method</h2>

    <?php if($message!=""){ ?>
        <div class="msg"><?php echo $message; ?></div>
    <?php } ?>

    <form method="POST">

        <input type="radio" name="payment" value="Cash On Delivery"> Cash On Delivery <br><br>

        <input type="radio" name="payment" value="UPI"> UPI <br><br>

        <input type="radio" name="payment" value="Credit Card"> Credit Card <br><br>

        <input type="radio" name="payment" value="Debit Card"> Debit Card <br><br>

        <button type="submit" name="pay">Pay Now</button>

    </form>

    <br>

    <a href="buynow.php">⬅ Back to oder</a>

</div>

</body>
</html>
