 <script>
        function validateForm(){

            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let password = document.getElementById("password").value;
            let confirmPassword = document.getElementById("confirmPassword").value;
            let phoneNumber = document.getElementById("phoneNumber").value.trim();

            if (name === "") 
            {
                alert("Name field is mandatory");
                return false;
            }
             let emailpattern=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

            if (!email.test(email) {
                alert("Email address is required");
                return false;
            }

            if (password.length < 8) 
            {
                alert("Password must contain at least 8 characters");
                return false;
            }
            if (password !== confirmPassword) 
            {
                alert("Passwords do not match");
                return false;
           }
            if (phoneNumber.length !== 10 || isNaN(phoneNumber)) {
                alert("Phone number must be exactly 10 digits");
                return false;
            }

            alert("Registration Successful!");
            return true;
            
        }
    </script>
