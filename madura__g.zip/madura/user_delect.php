<?php

class User {

    private $conn;

    public function __construct($db){
        $this->conn = $db;
    }

    public function deleteUser($id){

        $id = intval($id);

        $sql = "DELETE FROM user WHERE id=$id";

        if($this->conn->query($sql)){
            return true;
        } else {
            return false;
        }
    }
}

?>
