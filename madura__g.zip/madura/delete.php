<?php

session_start();

include "database.php";
include "user_delect.php";

$id= isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "DELETE FROM user WHERE id=$id";

if($conn->query($sql)){

    header("Location:view_table.php");
    exit();

}
else{

    echo "Error : ".$conn->error;

}

?>
