<?php

$message = "";

if(isset($_POST['order']))
{
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $payment = trim($_POST['payment']);

    if(
        empty($name) ||
        empty($phone) ||
        empty($address) ||
        empty($payment)
    ){
        $message = "Please fill all fields";
    }
    else{
        $message = "Order Placed Successfully using " . $payment;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Buy Now</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f4f4;
        }

        .container{
            width:350px;
            margin:80px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px #ccc;
        }

        h2{
            text-align:center;
        }

        input, textarea{
            width:100%;
            padding:10px;
            margin:8px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:green;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
            margin-top:10px;
        }

        .msg{
            text-align:center;
            color:green;
            margin-bottom:10px;
        }
        select
        {
    width:100%;
    padding:10px;
    margin:8px 0;
    border:1px solid #ccc;
    border-radius:5px;
}
    </style>
</head>
<body>

<div class="container">

    <h2>Buy Now</h2>

    <?php if(!empty($message)) { ?>
        <div class="msg"><?php echo $message; ?></div>
    <?php } ?>

    <form method="POST">
<form method="POST">

    <input type="text" name="name" placeholder="Enter Name">

    <input type="text" name="phone" placeholder="Enter Phone Number">

    <textarea name="address" placeholder="Enter Address"></textarea>

    <select name="payment">
        <option value="">Select Payment Method</option>
        <option value="Cash On Delivery">Cash On Delivery</option>
        <option value="UPI">UPI</option>
        <option value="Credit Card">Credit Card</option>
        <option value="Debit Card">Debit Card</option>
    </select>

    <button type="submit" name="order">
        Place Order
    </button>

</form>

    </form>

    <br>

    <a href="ecom.php">⬅ Back to Shop</a>

</div>

</body>
</html>


