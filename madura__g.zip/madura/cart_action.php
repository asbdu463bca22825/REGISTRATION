<?php
session_start();
include "database.php";

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;


$result = $conn->query("SELECT * FROM product WHERE id=$id");

if($result->num_rows > 0){

    $product = $result->fetch_assoc();

    
    if(!isset($_SESSION['cart'])){
        $_SESSION['cart'] = [];
    }

  
    if(isset($_SESSION['cart'][$id])){
        $_SESSION['cart'][$id]['qty'] += 1;
    }
    else{
        $_SESSION['cart'][$id] = [
            "name" => $product['name'],
            "price" => $product['price'],
            "image" => $product['image'],
            "qty" => 1
        ];
    }


    header("Location: cart.php");
    exit();
}
else{
    echo "Product not found";
}
?>
