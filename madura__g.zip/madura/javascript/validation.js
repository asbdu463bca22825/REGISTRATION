 <script>
        function validateForm(){

            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let password = document.getElementById("password").value;
            let confirmPassword = document.getElementById("confirmPassword").value;
            let phoneNumber = document.getElementById("phoneNumber").value.trim();
             let namePattern = /^[A-Za-z\s]{3,50}$/;

             if(!namePattern.test(name))
             {
                  alert("Name should contain only letters and spaces (3-50 characters)");
                  return false;
             }
            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$/;
                   if(!emailPattern.test(email))
                    {
                      alert("Please enter a valid email address");
                     return false;
                    }
 
            let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

             if(!passwordPattern.test(password))
             {
                    alert("Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character");
                    return false;
             }
            
            if (password !== confirmPassword) 
            {
                alert("Passwords do not match");
                return false;
           }
           let phonePattern = /^[0-9]{10}$/;

             if(!phonePattern.test(phoneNumber)) 
             {
                  alert("Phone number must be exactly 10 digits");
                   return false;
              }
            
            alert("Registration Successful!");
            return true;
            
        }
    </script>
