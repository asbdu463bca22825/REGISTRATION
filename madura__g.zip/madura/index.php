<?php
include "database.php";

?>


<!DOCTYPE html>
<html>
<head>
    <title>Register from</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
    
body{

    font-family: Arial;
    background-color: #1b1b32;;
}
form{
    width:400px;
    margin:100px auto;
    padding:20px;
    background-color: rgb(240, 242, 245);
    border-radius: 10px;
}
input{
    width:90%;
    padding: 10px;
    margin:8px auto;
}
button{
    width:100%;
    padding:10px;
    background-color: whit;
    color: aqua;
    border:non;


}
h1{
    text-align: center;
    background-color:rgb(240, 242, 245);
 
    

}
  
 </style>

</head>

<body>
 <script>
        function validateForm(){

            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let password = document.getElementById("password").value;
            let confirmpassword = document.getElementById("confirmpassword").value;
            let phonenum = document.getElementById("phonenum").value.trim();
             let namePattern = /^[A-Za-z\s]{3,50}$/;

             if(!namePattern.test(name))
             {
                  alert("Name should contain only letters and spaces (3-50 characters)");
                  return false;
             }
            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$/;
                   if(!emailPattern.test(email))
                    {
                      alert("Please enter a valid email address");
                     return false;
                    }
 
            let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

             if(!passwordPattern.test(password))
             {
                    alert("Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character");
                    return false;
             }
            
            if (password !== confirmpassword) 
            {
                alert("Passwords do not match");
                return false;
           }
           let phonePattern = /^[0-9]{10}$/;

             if(!phonePattern.test(phonenum)) 
             {
                  alert("Phone number must be exactly 10 digits");
                   return false;
              }
            
            alert("Registration Successful!");
            return true;
            
        }
    </script>
<form id="registerForm" method="POST" onsubmit="return validateForm()">
    <h2>Register Form</h2>

    <input type="text" id="name" name="name" placeholder="Enter Name"><br><br>

    <input type="email" id="email" name="email" placeholder="Enter Email"><br><br>

    <input type="password" id="password" name="password" placeholder="Enter Password"><br><br>

    <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password"><br><br>

    <input type="tel" id="phonenum" name="phonenum" placeholder="Enter Phone Number"><br><br>

    <button type="submit" name="submit">Register</button>

    <div id="show"></div>
</form>

 

<?php
if(isset($_POST['submit'])){

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $phonenum = trim($_POST['phonenum']);

    
    if(empty($name) || empty($email) || empty($password) || empty($phonenum)){
        die("<script>alert('Please fill all fields');</script>");
    }

   
    $check = $conn->query("SELECT * FROM user WHERE email='$email'");

    if($check->num_rows > 0){
        die("<script>alert('Email already registered');</script>");
    }

    
    $password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO user(name,email,password,phonenum)
            VALUES('$name','$email','$password','$phonenum')";

    if($conn->query($sql)){
        echo "<script>
                alert('Registration Successful');
                window.location='login.php';
              </script>";
    } 
    else
     {
        echo "Error: " . $conn->error;
    }
}
?>
</body>
</html>
