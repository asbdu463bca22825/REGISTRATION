<?php

class User {

    private $conn;

    public function __construct($db){
        $this->conn = $db;
    }

    
    public function getUserById($id){

        $id = intval($id);

        $sql = "SELECT * FROM user WHERE id=$id";
        $result = $this->conn->query($sql);

        return $result->fetch_assoc();
    }

   
    public function updateUser($id, $name, $email, $password, $phonenum){

        $id = intval($id);

        if(
            empty($name) ||
            empty($email) ||
            empty($password) ||
            empty($phonenum)
        ){
            return "Please fill all fields";
        }

        $sql = "UPDATE user SET
                name='$name',
                email='$email',
                password='$password',
                phonenum='$phonenum'
                WHERE id=$id";

        if($this->conn->query($sql)){
            return "success";
        } else {
            return "Error: " . $this->conn->error;
        }
    }
}

?>
